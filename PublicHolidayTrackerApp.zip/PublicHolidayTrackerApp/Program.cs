using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;

class Holiday
{
    public string date { get; set; }
    public string localName { get; set; }
    public string name { get; set; }
    public string countryCode { get; set; }

    // C# 'fixed' kelimesi anahtar kelime olduğu için başına @ koy
    public bool @fixed { get; set; }

    public bool global { get; set; }
}

class Program
{
    private static readonly Dictionary<int, List<Holiday>> _holidaysByYear = new Dictionary<int, List<Holiday>>();
    private static readonly int[] _years = new[] { 2023, 2024, 2025 };
    private static readonly HttpClient _httpClient = new HttpClient();

    static async Task Main(string[] args)
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;

        Console.WriteLine("Resmi tatil verileri API'den yükleniyor...\n");

        // Başta 3 yılın hepsini çek
        foreach (int year in _years)
        {
            try
            {
                var holidays = await GetHolidaysForYearAsync(year);
                _holidaysByYear[year] = holidays;
                Console.WriteLine($"{year} yılı için {holidays.Count} tatil yüklendi.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"{year} yılı için veri alınırken hata: {ex.Message}");
                _holidaysByYear[year] = new List<Holiday>();
            }
        }

        Console.WriteLine();
        RunMenu();
    }

    private static async Task<List<Holiday>> GetHolidaysForYearAsync(int year)
    {
        string url = $"https://date.nager.at/api/v3/PublicHolidays/{year}/TR";

        HttpResponseMessage response = await _httpClient.GetAsync(url);
        response.EnsureSuccessStatusCode();

        string json = await response.Content.ReadAsStringAsync();

        var holidays = JsonSerializer.Deserialize<List<Holiday>>(json, new JsonSerializerOptions
        {
            PropertyNameCaseInsensitive = true
        });

        return holidays ?? new List<Holiday>();
    }

    private static void RunMenu()
    {
        while (true)
        {
            Console.WriteLine("===== PublicHolidayTracker =====");
            Console.WriteLine("1. Tatil listesini göster (yıl seçmeli)");
            Console.WriteLine("2. Tarihe göre tatil ara (gg-aa formatı)");
            Console.WriteLine("3. İsme göre tatil ara");
            Console.WriteLine("4. Tüm tatilleri 3 yıl boyunca göster (2023–2025)");
            Console.WriteLine("5. Çıkış");
            Console.Write("Seçiminiz: ");

            string secim = Console.ReadLine();
            Console.WriteLine();

            switch (secim)
            {
                case "1":
                    ShowHolidaysForSelectedYear();
                    break;
                case "2":
                    SearchHolidayByDayMonth();
                    break;
                case "3":
                    SearchHolidayByName();
                    break;
                case "4":
                    ShowAllHolidays();
                    break;
                case "5":
                    Console.WriteLine("Programdan çıkılıyor...");
                    return;
                default:
                    Console.WriteLine("Geçersiz seçim, 1-5 arasında değer gir.");
                    break;
            }

            Console.WriteLine();
        }
    }

    // 1) Yıla göre tatil listesi
    private static void ShowHolidaysForSelectedYear()
    {
        Console.Write("Yıl girin (2023-2025): ");
        string yearInput = Console.ReadLine();

        if (!int.TryParse(yearInput, out int year) || !_years.Contains(year))
        {
            Console.WriteLine("Geçersiz yıl. Sadece 2023, 2024 veya 2025.");
            return;
        }

        if (!_holidaysByYear.TryGetValue(year, out var holidays) || holidays.Count == 0)
        {
            Console.WriteLine($"{year} için tatil bulunamadı veya veri alınamadı.");
            return;
        }

        Console.WriteLine($"{year} yılı resmi tatilleri:");
        Console.WriteLine("----------------------------------------");

        foreach (var h in holidays)
        {
            Console.WriteLine($"{h.date} - {h.localName} ({h.name})");
        }
    }

    // 2) GG-AA formatına göre tatil ara
    private static void SearchHolidayByDayMonth()
    {
        Console.Write("Tarih girin (gg-aa formatı, örnek: 29-10): ");
        string input = Console.ReadLine();

        if (string.IsNullOrWhiteSpace(input) || input.Length != 5 || input[2] != '-')
        {
            Console.WriteLine("Format hatalı. Örnek: 29-10");
            return;
        }

        string dayPart = input.Substring(0, 2);
        string monthPart = input.Substring(3, 2);

        if (!int.TryParse(dayPart, out int day) || !int.TryParse(monthPart, out int month))
        {
            Console.WriteLine("Gün veya ay sayısal değil.");
            return;
        }

        var results = new List<(int Year, Holiday Holiday)>();

        foreach (var kvp in _holidaysByYear)
        {
            int year = kvp.Key;
            foreach (var h in kvp.Value)
            {
                if (DateTime.TryParse(h.date, out DateTime date))
                {
                    if (date.Day == day && date.Month == month)
                    {
                        results.Add((year, h));
                    }
                }
            }
        }

        if (results.Count == 0)
        {
            Console.WriteLine("Bu güne denk gelen bir resmi tatil bulunamadı.");
            return;
        }

        Console.WriteLine("Bulunan tatiller:");
        Console.WriteLine("----------------------------------------");
        foreach (var item in results)
        {
            Console.WriteLine($"{item.Holiday.date} - {item.Holiday.localName} ({item.Holiday.name}) - Yıl: {item.Year}");
        }
    }

    // 3) İsimle arama (localName veya name)
    private static void SearchHolidayByName()
    {
        Console.Write("Tatil adı girin (örn: Cumhuriyet): ");
        string searchText = Console.ReadLine();

        if (string.IsNullOrWhiteSpace(searchText))
        {
            Console.WriteLine("Arama metni boş olamaz.");
            return;
        }

        searchText = searchText.ToLower();
        var results = new List<(int Year, Holiday Holiday)>();

        foreach (var kvp in _holidaysByYear)
        {
            int year = kvp.Key;
            foreach (var h in kvp.Value)
            {
                string local = h.localName != null ? h.localName.ToLower() : "";
                string name = h.name != null ? h.name.ToLower() : "";

                if (local.Contains(searchText) || name.Contains(searchText))
                {
                    results.Add((year, h));
                }
            }
        }

        if (results.Count == 0)
        {
            Console.WriteLine("Bu isimle eşleşen tatil bulunamadı.");
            return;
        }

        Console.WriteLine("Bulunan tatiller:");
        Console.WriteLine("----------------------------------------");
        foreach (var item in results)
        {
            Console.WriteLine($"{item.Holiday.date} - {item.Holiday.localName} ({item.Holiday.name}) - Yıl: {item.Year}");
        }
    }

    // 4) Tüm yıllardaki tatilleri göster
    private static void ShowAllHolidays()
    {
        Console.WriteLine("2023-2025 arasındaki tüm resmi tatiller:");
        Console.WriteLine("----------------------------------------");

        foreach (int year in _years)
        {
            Console.WriteLine($"\n== {year} ==");
            if (_holidaysByYear.TryGetValue(year, out var holidays) && holidays.Count > 0)
            {
                foreach (var h in holidays)
                {
                    Console.WriteLine($"{h.date} - {h.localName} ({h.name})");
                }
            }
            else
            {
                Console.WriteLine("Tatil bulunamadı veya veri yüklenmedi.");
            }
        }
    }
}
